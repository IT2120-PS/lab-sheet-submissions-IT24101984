#Set the path
setwd("C:\\Users\\Tharusha\\Desktop\\IT24101984")
getwd()

#import the data set
data <- read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)

#Q1.Calulate the population mean and the population standerd daviation
popmn<-mean(Weight.kg.)
popvar<-var(Weight.kg.)
popsd<-sqrt(popvar)

popmn
popsd


#Q2.Draw 25 random samples of size 6 (with replacement)
#Create null vectors to store samples

samples<-c()
n<-c()

for(i in 1:25){
  s<-sample(Weight.kg.,6,replace = TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('S',i))
}

#Assign Column names
colnames(samples)=n
s.means<-apply(samples,2,mean)
s.sd<-apply(samples,2,sd)
s.means

s.sd

##3.Calculate the mean and standard deviation of the 25 sample means and state the relationship
#of them with true mean and true standard deviation

#Calculate sample mean and standerd deviation
samplemean<-mean(s.means)
samplevars<-var(s.means)
samplesd<-sd(s.means)

true_mean<-popmn
true_sd<-popsd / sqrt(6)

samplemean
true_mean

samplesd
true_sd




